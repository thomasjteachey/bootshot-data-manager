import { useEffect, useState } from "react";

type DbForm = {
  host: string;
  port: number;
  user: string;
  password: string;
  database: string;
  ssl: boolean;
};

export default function SettingsPanel({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState<DbForm>({
    host: "localhost",
    port: 3306,
    user: "",
    password: "",
    database: "",
    ssl: false,
  });

  const [status, setStatus] = useState<string>("");

  useEffect(() => {
    // If your preload/settings bridge isn't ready yet,
    // this will fail silently instead of crashing.
    window.bootshot?.settings?.getDb?.()
      .then((db) => setForm(db))
      .catch(() => {});
  }, []);

  const save = async () => {
    setStatus("");
    try {
      await window.bootshot.settings.setDb(form);
      setStatus("Saved.");
      onClose();
    } catch (e) {
      setStatus("Failed to save settings.");
    }
  };

  const update = <K extends keyof DbForm>(key: K, value: DbForm[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "white",
        zIndex: 9999,
      }}
    >
      <div
        style={{
          width: 440,
          background: "#0f0f0f",
          border: "1px solid #2a2a2a",
          borderRadius: 10,
          padding: 18,
          boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
        }}
      >
        <div style={{ fontSize: 18, marginBottom: 12 }}>
          Settings — Database
        </div>

        <div style={{ display: "grid", gap: 8 }}>
          <label>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Host</div>
            <input
              value={form.host}
              onChange={(e) => update("host", e.target.value)}
              style={{ width: "100%" }}
            />
          </label>

          <label>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Port</div>
            <input
              type="number"
              value={form.port}
              onChange={(e) => update("port", Number(e.target.value))}
              style={{ width: "100%" }}
            />
          </label>

          <label>
            <div style={{ fontSize: 12, opacity: 0.8 }}>User</div>
            <input
              value={form.user}
              onChange={(e) => update("user", e.target.value)}
              style={{ width: "100%" }}
            />
          </label>

          <label>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Password</div>
            <input
              type="password"
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              style={{ width: "100%" }}
            />
          </label>

          <label>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Database</div>
            <input
              value={form.database}
              onChange={(e) => update("database", e.target.value)}
              style={{ width: "100%" }}
            />
          </label>

          <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={form.ssl}
              onChange={(e) => update("ssl", e.target.checked)}
            />
            <span style={{ fontSize: 12, opacity: 0.85 }}>Use SSL</span>
          </label>
        </div>

        {status && (
          <div style={{ marginTop: 10, fontSize: 12, opacity: 0.85 }}>
            {status}
          </div>
        )}

        <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
          <button onClick={save}>Save</button>
          <button onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
