import { useEffect, useRef, useState } from "react";
import SettingsPanel from "./SettingsPanel";

export default function App() {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = window.innerWidth;
      const h = window.innerHeight;

      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      ctx.fillStyle = "black";
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = "white";
      ctx.font = "12px sans-serif";
      ctx.fillText("blankpad ready", 12, 20);
      ctx.fillText("File → Settings…", 12, 38);
    };

    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  useEffect(() => {
    // If this logs undefined, your preload isn't loading.
    // But we won't rely on logs here — just guard safely.
    const off = window.bootshot?.ui?.onOpenSettings?.(() => {
      setShowSettings(true);
    });

    return () => {
      if (off) off();
    };
  }, []);

  return (
    <>
      <canvas
        ref={ref}
        style={{
          display: "block",
          width: "100vw",
          height: "100vh",
          background: "black",
        }}
      />

      {showSettings && (
        <SettingsPanel onClose={() => setShowSettings(false)} />
      )}
    </>
  );
}
