import { contextBridge, ipcRenderer } from "electron";

// If you haven't wired settings storage yet,
// keep a tiny stub so the UI doesn't crash.
const settingsApi = {
  getDb: async () => ({
    host: "localhost",
    port: 3306,
    user: "",
    password: "",
    database: "",
    ssl: false,
  }),
  setDb: async (partial: any) => partial,
};

const uiApi = {
  onOpenSettings: (fn: () => void) => {
    const handler = () => fn();
    ipcRenderer.on("ui:open-settings", handler);
    return () => ipcRenderer.removeListener("ui:open-settings", handler);
  },
};

contextBridge.exposeInMainWorld("bootshot", {
  ui: uiApi,
  settings: settingsApi,
});
